using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class brush : MonoBehaviour
{
    
    private Vector3 mousePosition;
    private Vector3 brushPosition;
    public float moveSpeed = 0.1f;
    public float offset;
    public KeyCode mouseLeft;
    public Transform baseDot;
    

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
            mousePosition = Input.mousePosition;
            mousePosition = Camera.main.ScreenToWorldPoint(mousePosition);
            brushPosition = new Vector3(mousePosition.x,mousePosition.y+offset,mousePosition.z);
            transform.position = Vector2.Lerp(transform.position, brushPosition, moveSpeed);
        
        if (Input.GetMouseButtonDown (0)) {
            
        /*RaycastHit2D hitInfo = new RaycastHit2D ();
        if (Physics2D.Raycast (Camera.main.ScreenPointToRay (Input.mousePosition), out hitInfo)) {
        Debug.Log ("Object Hit is " + hitInfo.collider.gameObject.name);
            
        }*/
        }

    
    }
        
    /*void OnTriggerEnter2D(Collider2D other){
        if(other.tag == "hand"){
            Debug.Log("works");
            if (Input.GetKey (mouseLeft)){
            mousePosition = new Vector3(mousePosition.x,mousePosition.y,10);
            Instantiate(baseDot, mousePosition, baseDot.rotation);
            }
        }
    }*/
}
 